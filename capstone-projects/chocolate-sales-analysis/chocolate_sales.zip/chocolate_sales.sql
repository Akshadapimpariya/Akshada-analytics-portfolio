drop table if exists chocolate_sales;
CREATE TABLE chocolate_sales (
  sales_person  VARCHAR(50),
  country       VARCHAR(50),
  product       VARCHAR(100),
  sales_date    text,
  amount        text,
  boxes_shipped float
);

select *
from chocolate_sales;

update chocolate_sales
set amount = replace(replace(amount,'$',''),',','')

ALTER TABLE chocolate_sales
ALTER COLUMN amount
type numeric(12,2)
using amount :: numeric;

ALTER TABLE chocolate_sales
ALTER COLUMN sales_date
type date
using sales_date:: date;

SET datestyle = 'ISO,DMY';

ALTER TABLE chocolate_sales
ALTER COLUMN boxes_shipped
type int
using boxes_shipped::int;

SELECT * FROM chocolate_sales;

-- deleting null from the sales_date and amount so that we can perform trend or financial analysis
delete from chocolate_sales
where amount is null 
or sales_date is null;

-- replacing null with unknown and N/A from sales person and country
update chocolate_sales
set sales_person = coalesce(sales_person,'unknown'),
    country = coalesce(country,'N/A');

-- replacing the null products with unknown
update chocolate_sales
set product = 'unknown'
where product is null;

-- The "Derived Imputation" Update for boxes_shipped
UPDATE chocolate_sales s
SET boxes_shipped = ROUND(s.amount / ppb_lookup.avg_price_per_box)
FROM (
    -- Subquery to find the average price per box for every product
    SELECT product, AVG(amount / boxes_shipped) as avg_price_per_box
    FROM chocolate_sales
    WHERE boxes_shipped IS NOT NULL AND boxes_shipped > 0
    GROUP BY product
) AS ppb_lookup
WHERE s.product = ppb_lookup.product
  AND s.boxes_shipped IS NULL;

-- Show 'No Product' if the name is missing and $0.00$ for null amounts.
select 
sales_person,
COALESCE(product,'no product'),
COALESCE(amount, 0)
from chocolate_Sales;

-- Find all sales larger than the global average.
SELECT * from chocolate_sales
where amount > (Select avg(amount) from chocolate_sales)

-- show each sale alongside the total revenue of its country.
select *,
sum(amount) over(partition by country) as country_Revenue_total
from chocolate_sales;

-- Products sold in the USA but never in India.
select distinct product from chocolate_Sales where country = 'USA' and
product not in (select product from chocolate_sales where country = 'india');

-- Sales people with > 10,000 total boxes.
select 
sales_person,
sum(boxes_shipped)
from chocolate_Sales
group by 1
having sum(boxes_Shipped) > 10000;

-- Sales people whose average sale is higher than the USA's average
select 
sales_person,
avg(Amount) as avg_Sales
from chocolate_Sales
group by 1
having avg(amount) > (select 
                      avg(amount)
					  from chocolate_sales
					  where country = 'USA');

-- Categorize products as 'Premium' if average price per box > $50.
SELECT
product,
case when avg_ppb > 50 then 'premium'
else 'standard' end
from(select
     product,
	 avg(amount/boxes_shipped) as avg_ppb
	 from chocolate_sales
	 group by product)

-- For each sale, count how many sales in that country were larger.
SELECT
*,count(*) filter( where amount > s.amount) over(partition by country) as large_Sales_country
from chocolate_sales s;

-- Products sold in 2023 but not in 2024.
SELECT
product 
from chocolate_Sales
where extract(year from sales_date) = 2023
except select product from chocolate_Sales where extract(year from sales_date) = 2024;

-- If country is NULL, use 'International' as the label.
SELECT 
sales_person, 
COALESCE(country, 'International') FROM chocolate_sales;

-- Show total revenue for each country, but split it into three columns: 2023, 2024, and 2025.
SELECT
country,
sum(case when extract(year from sales_date) = 2023 then amount else 0 end) as sales_2023,
sum(case when extract(year from sales_date) = 2024 then amount else 0 end) as sales_2024,
sum(case when extract(year from sales_Date) = 2025 then amount else 0 end) as sales_205
from chocolate_sales
group by country;

-- Find pairs of products that are frequently sold on the same day by the same salesperson (indicates a likely "bundle" or cross-sell).
SELECT
a.product as product_1,
b.product as product_2,
count(*) as times_sold_together
from chocolate_sales a
join chocolate_sales b
on b.sales_date = a.sales_date
and b.sales_person = a.sales_person
and a.product < b.product
group by 1,2
order by times_sold_together desc;

-- For every sale, show the current sale amount alongside the single largest sale that salesperson has ever made in their history.
SELECT
sales_person,
amount,
sales_date,
first_value(amount) over(partition by sales_person order by amount desc) as personal_best
from chocolate_sales;

-- Calculate the "Acceleration" of sales—the difference in the gap between the last two sales. Is the person selling faster or slower?
WITH TimeDiffs AS (
    SELECT sales_person, sales_date,
           sales_date - LAG(sales_date) OVER(PARTITION BY sales_person ORDER BY sales_date) as current_gap,
           LAG(sales_date, 1) OVER(PARTITION BY sales_person ORDER BY sales_date) - 
           LAG(sales_date, 2) OVER(PARTITION BY sales_person ORDER BY sales_date) as previous_gap
    FROM chocolate_sales
)
SELECT *, (current_gap - previous_gap) as acceleration_score FROM TimeDiffs;

-- Calculate the actual Median sale amount for each country. (Unlike AVG, MEDIAN is resistant to outliers).
SELECT
country,
percentile_cont(0.5) within GROUP (order by amount) as median
from chocolate_sales
group by country;

-- Find sales people whose rolling 3-sale average exceeds $\$15,000$.
SELECT *
from (select
sales_person,sales_date,amount,
avg(amount) over(partition by sales_person order by sales_date rows between 2 preceding and current row) as rolling_3_avg
from chocolate_sales)t
where rolling_3_avg > 15000;

-- Rank products by revenue, but ensure if two products have the same revenue, they get the same rank, and the next rank is not skipped.
with product_rank as(
     select product,sum(amount) as total_revenue,
	 dense_rank() over(order by sum(amount) desc) rn
	 from chocolate_sales
	 group by product
)
select * from product_rank;

-- Find all products that contain numbers in their names (e.g., "70% Dark") and extract only the numeric part.
select product,
       substring(product from '[0-9]+') as numeric_part
from chocolate_sales
where product ~ '[0-9]+';

